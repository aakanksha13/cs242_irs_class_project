from pymongo import MongoClient
import re
import sys

def main_function(queries):
    query = [''] * 5
    for i in range(len(queries)):
        query[i] = queries[i]
    client = MongoClient('localhost', 27017)

    db = client.IR
    collection = db.test

    output = collection.aggregate([{'$match': { 'id': {'$in' : [re.compile('^' + re.escape(query[0]) + '$', re.IGNORECASE) , re.compile('^' + re.escape(query[1]) + '$', re.IGNORECASE), re.compile('^' + re.escape(query[2]) + '$', re.IGNORECASE)]}}}, {'$group': {'_id': {'URL':'$URL', 'Title':'$Title','Description':'$Description'}, 'count' : { '$sum' : '$Count' }}}, {'$sort':{'count': -1}}])
    print()
    for out in output:
        print(out)

if __name__ == "__main__":
    main_function(sys.argv[1:])
