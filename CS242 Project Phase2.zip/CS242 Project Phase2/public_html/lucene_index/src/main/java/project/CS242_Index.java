package project;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.CharArraySet;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexableField;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.RAMDirectory;
import org.jsoup.Jsoup;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.HashMap;

import static java.nio.file.Files.newBufferedReader;





public class CS242_Index 
{
    public static String remove_html(String html) {
        if(html != null && !html.isEmpty()) {
            String text = Jsoup.parse(html).text();
            return text;
        }
        else return "";
    }

    public static void main( String[] args ) throws IOException, ParseException {
        // add stop words
        StandardAnalyzer analyzer = null;
        CharArraySet stopSet = CharArraySet.copy( StandardAnalyzer.STOP_WORDS_SET);
        stopSet.add("ingredients");
        stopSet.add("recipes");
        stopSet.add("directions");
        stopSet.add("duration");
        stopSet.add("nutrition");
        analyzer = new StandardAnalyzer(stopSet);
        String pwd = args[0];//record present directory, where all files are
        String queryString = args[1]; //record user-supplied query
        Directory directory = FSDirectory.open(Paths.get(pwd + "/indextest"));
        IndexWriterConfig config = new IndexWriterConfig(analyzer);
        IndexWriter indexWriter = new IndexWriter(directory, config);


        //this is where the outputs of the crawler are stored
        //iterate through all the crawled files



        //this is where the outputs of the crawler are stored
        //iterate through all the crawled files
        String file_path = pwd + "/outputs/foodie_crush_output";
        Integer i = 1;
        System.out.println("Generating FoodieCrush Indices");

        while (i < 32) {
            if (i != 26) {

                Document doc = new Document();
                try (BufferedReader r = newBufferedReader(Paths.get(file_path.concat(i.toString()).concat(".txt")), StandardCharsets.UTF_8)) {
                    String line;
                    String cleanLine;
                    String field_name;
                    while ((line = r.readLine()) != null) {
                        field_name = "content";
                        if (line.contains("<meta property=\"og:url\" content=\"")) {
                            String[] url_parts = line.split("<meta property=\"og:url\" content=\"");
                            String url = url_parts[1].substring(0, url_parts[1].length() - 4);
                            doc.add(new TextField("url", url, Field.Store.YES));
                        }
			if(line.contains("twitter:description")){

				String[] dParts = line.split("\"");
				String description = dParts[3];
				if(description.length() > 280)
					description = description.substring(0,281) + "...";

				doc.add(new TextField("snippet", description, Field.Store.YES));
			}
                        cleanLine = remove_html(line);

                        if (!cleanLine.isEmpty()) {
                            //I put stars in the crawler output to separate the recipes
                            if (cleanLine.equals("*********************************************************")) {
                                //when the line being read is stars (recipe separator), add the doc to the index and create a new doc
                                indexWriter.addDocument(doc);
                                doc = new Document();

                            } else {
                                doc.add(new TextField(field_name, cleanLine, Field.Store.YES));

                            }
                        }
                    }

                }


            }
            i++;
        }

        i = 1;
        file_path = pwd + "/combined_files.txt";
        System.out.println("Generating Chowhound Indices");
        while (i < 2) {
            Document doc = new Document();
            try (BufferedReader r = newBufferedReader(Paths.get(file_path),
                    StandardCharsets.UTF_8)) {

                String line;
                String cleanLine;
                while ((line = r.readLine()) != null) {
		    if(line.contains("og:url")){

			String[] urlParts = line.split("\"");
			String url = urlParts[1];

			doc.add(new TextField("url", url, Field.Store.YES));
		    }
		    if(line.contains("data-description")){

			    String[] dParts = line.split("\"");
			    String description = dParts[13];

			    doc.add(new TextField("snippet", description, Field.Store.YES));
		    }
                    cleanLine = remove_html(line);
                    if (!cleanLine.isEmpty()) {
                        // I put stars in the output to separate the recipes
                        if (cleanLine.equals("*********************************************************")) {
                            // when the line being read is stars (recipe separator), add the doc to the
                            // index and create a new doc
                            indexWriter.addDocument(doc);
                            doc = new Document();

                        } else {
                            doc.add(new TextField("content", cleanLine, Field.Store.YES));
                            // print out what is being added to the document for testing purposes
                        }

                    }
                }
                i++;

            }

        }

        file_path = pwd + "/allRecipesTogether.txt";
        System.out.println("Generating Epicurious Indices");
        try (BufferedReader r = newBufferedReader(Paths.get(file_path), StandardCharsets.UTF_8)) {
            Document doc = new Document();
            String line;
	    String lastLine = "";
            String cleanLine;
            String field_name;
            while ((line = r.readLine()) != null) {
                field_name = "content";
                if (line.contains("og:url")) {
                    int firstQuote = line.indexOf('"');
                    int secondQuote = line.indexOf('"', firstQuote + 1);
                    String url = line.substring(firstQuote + 1, secondQuote);
                    doc.add(new TextField("url", url, Field.Store.YES));
                }
		if (line.contains("og:description")) {
			if(!line.startsWith("<meta")){
				line = lastLine + line;
			}

			String[] lineParts = line.split("\"");
			String snippet = line.substring(0, line.lastIndexOf("property=")).trim();
			if(snippet.startsWith("<meta")){

				int snipStart = snippet.length() - 1;
				while(snippet.charAt(snipStart) != '=')
					snipStart--;
				snippet = snippet.substring(snipStart+2, snippet.length()-2).trim().replaceAll("        "," ");
			}
			else {
				if(snippet.length() > 1)
					snippet = snippet.substring(0,snippet.length()-2).trim().replaceAll("        ", " ");
				else
					snippet = "";
			}
			if(snippet.length() > 280)
				snippet = snippet.substring(0,281) + "...";

			doc.add(new TextField("snippet", snippet, Field.Store.YES));
		}
                cleanLine = remove_html(line);

                if (!cleanLine.isEmpty()) {
                    //I put stars in the crawler output to separate the recipes
                    if (cleanLine.equals("------------------------------------")) {
                        //when the line being read is stars (recipe separator), add the doc to the index and create a new doc
                        indexWriter.addDocument(doc);
                        doc = new Document();

                    } else {
                        doc.add(new TextField(field_name, cleanLine, Field.Store.YES));

                    }
                }
		lastLine = line;
            }

        }

        indexWriter.close();
	directory.close();
    }
}
