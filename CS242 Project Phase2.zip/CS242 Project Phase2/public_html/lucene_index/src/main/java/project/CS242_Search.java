package project;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.CharArraySet;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexableField;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.RAMDirectory;
import org.jsoup.Jsoup;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.HashMap;

import static java.nio.file.Files.newBufferedReader;





public class CS242_Search 
{
    public static String remove_html(String html) {
        if(html != null && !html.isEmpty()) {
            String text = Jsoup.parse(html).text();
            return text;
        }
        else return "";
    }

    public static void main( String[] args ) throws IOException, ParseException {
        String pwd = args[0];//record present directory, where all files are
        String queryString = args[1]; //record user-supplied query

        // To store an index on disk, use this instead:
        Directory directory = FSDirectory.open(Paths.get(pwd + "/indextest"));

        // Now search the index:
        DirectoryReader indexReader = DirectoryReader.open(directory);
        IndexSearcher indexSearcher = new IndexSearcher(indexReader);
        QueryParser parser = new QueryParser("content", analyzer);

        //This is the query that you'll be indexing the documents by
        Query query = parser.parse(queryString);

        System.out.println("");
        System.out.println("------------------------ RESULTS --------------------------");
        System.out.println(query.toString());
	int maxToRetrieve = 200;
        int topHitCount = 10;
        ScoreDoc[] hits = indexSearcher.search(query, maxToRetrieve).scoreDocs;
	HashMap<String, String> tops = new HashMap<String, String>();

        // Iterate through the results:
        for (int rank = 0; rank < hits.length; ++rank) {
            Document hitDoc = indexSearcher.doc(hits[rank].doc);
	    if(tops.size() < topHitCount){
	            tops.put(hitDoc.get("content"), (rank + 1) + " (score:" + hits[rank].score + ")--> " + hitDoc.get("content")+" -- "+hitDoc.get("url") + " |" + hitDoc.get("snippet") + "");
	    }
	    else
		    break;


        }
        indexReader.close();
        directory.close();


	for(String key : tops.keySet())
		System.out.println(tops.get(key));


    }
}
