public class Test4 {

	public static void main(String[] args) {		
		int x = 10;
        do {
            x++;
           }while( x < 40 );	
	}	
}